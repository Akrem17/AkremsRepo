export class work{
    date!:string;
    position!:string;
    company!:string;
    city!:string;
    details!:string;

}