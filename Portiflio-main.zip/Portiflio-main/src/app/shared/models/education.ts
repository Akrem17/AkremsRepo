export class education{
    date!:string;
    college!:string;
    field!:string;
    city!:string;
    details!:string;

}