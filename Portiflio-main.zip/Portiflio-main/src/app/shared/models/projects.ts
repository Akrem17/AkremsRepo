export class projects{
    title!:string;
    position!:string;
    details!:string;
    imgUrl!:string;

}